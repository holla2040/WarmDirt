board
    WarmDirt

version
    1.0

git location
    https://github.com/rethinksun/WarmDirt

description
    2 layer board
        cmp component side
        crc component cream
        crs solder cream
        drd drill data
        dri drill info
        gpi gerber info
        plc component side silkscreen
        pls solder side silkscreen
        sol solder side
        stc component side solder stop mask
        sts solder side solder stop mask
        readme.txt info, has fudicial info

fudicials at
    7.62mm x 7.62mm
    93.98mm x 93.98mm

layer stack up sequence
    top     x.cmp
    bottom  x.sol

contact info
    Craig Hollabaugh
    970 690 4911
    chollabaugh@rethinksun.com


