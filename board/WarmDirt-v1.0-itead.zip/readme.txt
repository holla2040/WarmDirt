board
    WarmDirt

version
    1.0

git location
    https://github.com/rethinksun/WarmDirt

description - iteadstudio
    Top layer:                  pcbname.GTL
    Bottom layer:               pcbname.GBL
    Solder Stop Mask top:       pcbname.GTS
    Solder Stop Mask Bottom:    pcbname.GBS
    Silk Top:                   pcbname.GTO
    Silk Bottom:                pcbname.GBO
    NC Drill:                   pcbname.TXT
    readme.txt                  info, has fudicial info

fudicials at
    7.62mm x 7.62mm
    93.98mm x 93.98mm

layer stack up sequence
    top     x.cmp
    bottom  x.sol

contact info
    Craig Hollabaugh
    970 690 4911
    chollabaugh@rethinksun.com


